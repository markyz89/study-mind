



var firstRadio = document.getElementsByClassName('radio-label')[0];

firstRadio
<span class=​"input-label radio-label  img-thumbnail">​Medicine​</span>​
firstRadio.style.background = "red";
"red"
var secondRadio = document.getElementsByClassName('radio-label')[1];
undefined
secondRadio.style.background = "blue";
"blue"