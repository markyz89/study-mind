<div class="whatsapp-contact">
	<a class = "whatsapp-button" href="https://wa.me/447898211341?text=Hi%20there%20I'm%20interested%20in%201%20to%201%20tutoring%20for%20UKCAT">Send us a Whatsapp <img src="<?php echo get_template_directory_uri() . '/img/whatsapp.png'?>"></a>
</div>