<div class="cta-form">
	<div class="desktop-form desktop-form-1">
		<?php gravity_form( 1, $display_title = false, $display_description = false, $display_inactive = false, $field_values = null, $ajax = true, $tabindex, $echo = true ); ?>
	</div>
	
	<div class="mobile-form">
		<?php gravity_form( 7, $display_title = false, $display_description = false, $display_inactive = false, $field_values = null, $ajax = true, $tabindex, $echo = true ); ?>
	</div>

</div>