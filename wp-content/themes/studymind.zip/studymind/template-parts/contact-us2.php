<div class="cta-2 cta-form">
	<div class="desktop-form-2 desktop-form">
		<?php gravity_form( 6, $display_title = false, $display_description = false, $display_inactive = false, $field_values = null, $ajax = true, $tabindex, $echo = true ); ?>
	</div>
	

	<div class="mobile-form">
		<?php gravity_form( 8, $display_title = false, $display_description = false, $display_inactive = false, $field_values = null, $ajax = true, $tabindex, $echo = true ); ?>
	</div>
</div>