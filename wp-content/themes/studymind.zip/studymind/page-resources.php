<?php get_header(); ?>

<?php get_template_part('template-parts/resource','navigation'); ?>

<?php get_template_part('template-parts/contact','us'); ?>



<?php get_footer(); ?>